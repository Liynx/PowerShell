﻿#remove all users directories in the users folder
Remove-Item -Path '\\powerdc\sharev3$\users\*' -Recurse
#remove all OUs and the users contained in them
Get-ADOrganizationalUnit -Filter 'Name -like "Group*"' | Set-ADObject -ProtectedFromAccidentalDeletion $false `
-PassThru | Remove-ADOrganizationalUnit -Confirm:$false -Recursive